---
title: News in 60 Seconds
emoji: 📻
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 6.32.0
app_file: app.py
pinned: false
license: cc-by-nc-sa-4.0
short_description: Spanish news summaries in 120 words or less for radio
---

# News in 60 Seconds · Radio Cumbres

Paste a news article in Spanish and get a summary of 120 words or less (about 60 seconds on air).
The summary comes from mT5 (XL-Sum) and is checked against the article: numbers and names that do not
appear in the news story are highlighted for review.

Team 4 · RNAP Hack 2026.
