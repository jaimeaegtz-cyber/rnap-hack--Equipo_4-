"""
News in 60 Seconds · Radio Cumbres — Interfaz v1 (Equipo 4, RNAP Hack 2026)

Recibe una noticia en español y devuelve un resumen de 120 palabras o menos (unos 60 s al aire),
generado por el mT5 y revisado por el verificador de cifras y nombres (ver resumidor.py).

Cómo correrla
  pip install -r requirements.txt
  python app.py                                  # usa el mT5 sin ajuste de Hugging Face
  MODEL_DIR=/ruta/al/modelo python app.py        # usa el modelo ajustado (carpeta guardada en el cuaderno, 4.5)
  MODEL_DIR=/ruta/al/modelo python app.py --share  # en Colab: enlace público temporal
"""
import argparse
import inspect
import os
import re
import time

import gradio as gr

from resumidor import LIMITE_PALABRAS, Resumidor, contar_palabras

MODEL_DIR = os.getenv('MODEL_DIR', 'csebuetnlp/mT5_multilingual_XLSum')
ETIQUETA = 'no aparece en la noticia'
MIN_PALABRAS = 10      # menos que esto no es una noticia
TEXTO_CORTO = 40       # abajo de esto se avisa que el texto es muy corto

# Noticia inventada para probar la interfaz (lugares y personas ficticios)
EJEMPLO = (
    'La comunidad de Valle Alto, en la sierra, inauguró este martes su primera clínica de salud, después de '
    'cuatro años de gestiones de los vecinos ante el gobierno estatal. La clínica atenderá a unas 3.200 personas '
    'de seis rancherías que hasta ahora tenían que viajar más de dos horas por un camino de terracería para llegar '
    'al hospital más cercano, en Ciudad Serrana.\n\n'
    'La obra costó 18 millones de pesos y cuenta con dos consultorios, una sala de partos y una farmacia. La '
    'directora de la clínica, la doctora Marina Ochoa, explicó que el personal estará formado por dos médicos, '
    'cuatro enfermeras y un promotor de salud que habla la lengua de la región.\n\n'
    '"Antes, una emergencia en la noche era casi imposible de atender", dijo Tomás Hernández, comisario ejidal '
    'de Valle Alto, durante la ceremonia de inauguración. Hernández agradeció a las familias que donaron el '
    'terreno donde se construyó el edificio.\n\n'
    'La clínica abrirá de lunes a sábado de 8:00 a 20:00 horas. Las autoridades estatales informaron que en 2027 '
    'se agregará una ambulancia para trasladar a los pacientes graves al hospital de Ciudad Serrana.'
)

print(f'Cargando modelo: {MODEL_DIR}')
resumidor = Resumidor(MODEL_DIR)
t0 = time.time()
resumidor.resumir(EJEMPLO)   # calentamiento: la primera llamada siempre es más lenta
print(f'Modelo listo en {resumidor.device} (resumen de prueba en {time.time() - t0:.1f} s)')


def segmentos(resumen, faltan):
    """Parte el resumen en trozos y marca los datos que no están en la noticia."""
    marcados = set(faltan)
    out = []
    for trozo in re.split(r'(\w[\w.,]*\w|\w)', resumen):
        if not trozo:
            continue
        norm = re.sub(r'[.,]', '', trozo)
        out.append((trozo, ETIQUETA if (trozo in marcados or norm in marcados) else None))
    return out


def contar(texto):
    n = contar_palabras(texto or '')
    return f'Noticia: **{n}** palabras' if n else 'Noticia: pega el texto completo'


def resumir(texto):
    texto = (texto or '').strip()
    if contar_palabras(texto) < MIN_PALABRAS:
        raise gr.Error(f'Pega el texto de la noticia (al menos {MIN_PALABRAS} palabras).')
    t0 = time.time()
    r = resumidor.resumir(texto)
    seg = time.time() - t0

    if r['aprobado']:
        estado = (f'### ✅ Listo para leer al aire\n'
                  f'Todas las cifras y nombres del resumen aparecen en la noticia.')
    else:
        estado = (f'### ⚠️ Revisar antes de salir al aire\n'
                  f'Estos datos no aparecen en la noticia: **{", ".join(r["no_encontrados"])}**. '
                  f'Corrígelos en el cuadro del resumen o elige otro candidato.')
    detalles = [f'**{r["palabras"]}** palabras · **≈{r["segundos"]:.0f} s** al aire '
                f'(límite: {LIMITE_PALABRAS} palabras / 60 s)']
    if r['indice'] > 0:
        detalles.append(f'El candidato más probable traía datos sin respaldo; se usó el candidato {r["indice"] + 1}.')
    if r['palabras_articulo'] < TEXTO_CORTO:
        detalles.append(f'El texto es muy corto ({r["palabras_articulo"]} palabras). El modelo se entrenó con notas completas '
                        'y con textos cortos se equivoca más: revisa el resumen con cuidado (el texto original ya cabe en 60 s).')
    if r['palabras_leidas'] < r['palabras_articulo']:
        pct = 100 * r['palabras_leidas'] / r['palabras_articulo']
        detalles.append(f'El modelo leyó las primeras {r["palabras_leidas"]} de {r["palabras_articulo"]} palabras '
                        f'({pct:.0f} %). Si lo importante está al final de la nota, revisa el resumen.')
    detalles.append(f'Tiempo: {seg:.1f} s · Modelo: `{os.path.basename(MODEL_DIR.rstrip("/"))}`')
    estado += '\n\n' + '\n\n'.join(detalles)

    filas = [[k + 1, c, ', '.join(f) if f else '✓ ninguno'] for k, (c, f) in enumerate(r['candidatos'])]
    return r['resumen'], segmentos(r['resumen'], r['no_encontrados']), estado, filas


with gr.Blocks(title='News in 60 Seconds · Radio Cumbres') as demo:
    gr.Markdown('# News in 60 Seconds · Radio Cumbres\n'
                'Pega una noticia en español. El sistema escribe un resumen de **120 palabras o menos** '
                '(unos 60 segundos al aire) y revisa que sus cifras y nombres estén en la noticia.')
    with gr.Row():
        with gr.Column(scale=1):
            entrada = gr.Textbox(label='Noticia', lines=16, placeholder='Pega aquí el texto de la noticia…')
            conteo = gr.Markdown(contar(''))
            with gr.Row():
                limpiar_btn = gr.ClearButton(value='Limpiar')
                boton = gr.Button('Resumir', variant='primary')
            gr.Examples([[EJEMPLO]], inputs=[entrada], label='Ejemplo (noticia inventada)')
        with gr.Column(scale=1):
            salida = gr.Textbox(label='Resumen para leer al aire (puedes editarlo)', lines=6, interactive=True)
            estado = gr.Markdown()
            marcado = gr.HighlightedText(label='Verificación: datos que no aparecen en la noticia',
                                         color_map={ETIQUETA: 'red'}, show_legend=True)
            with gr.Accordion('Otros candidatos del modelo', open=False):
                tabla = gr.Dataframe(headers=['#', 'Candidato', 'Datos sin respaldo'],
                                     datatype=['number', 'str', 'str'], wrap=True, interactive=False,
                                     column_widths=['8%', '67%', '25%'])

    limpiar_btn.add([entrada, salida, marcado, estado, tabla])
    entrada.change(contar, entrada, conteo, show_progress='hidden')
    boton.click(resumir, entrada, [salida, marcado, estado, tabla])
    gr.Markdown(f'<small>Equipo 4 · RNAP Hack 2026 · Modelo: {os.path.basename(MODEL_DIR.rstrip("/"))} '
                '(mT5, XL-Sum). El resumen es un borrador: revísalo antes de leerlo al aire.</small>')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--share', action='store_true', help='enlace público temporal (útil en Colab)')
    ap.add_argument('--port', type=int, default=int(os.getenv('PORT', 7860)))
    args = ap.parse_args()
    extra = {'theme': gr.themes.Soft()} if 'theme' in inspect.signature(demo.launch).parameters else {}
    demo.launch(share=args.share, server_name='0.0.0.0', server_port=args.port, **extra)
