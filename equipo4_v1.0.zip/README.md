# News in 60 Seconds · Radio Cumbres

**Team 4 · RNAP Hack 2026 (Neural Networks and Deep Learning)**
Jaime Esquivel, Alberto Moreno, Jared Dávila, Randhu

### ▶ Live demo: [https://huggingface.co/spaces/USER/news-in-60-seconds](https://huggingface.co/spaces/USER/news-in-60-seconds)
<!-- Replace USER with your Hugging Face username after running Annex B of the notebook. -->

![Interface v1](capturas/interfaz_v1.png)

## The problem
Radio Cumbres, a community radio station, needs to read the news on air in about one minute. Our system takes a news article in Spanish and writes a summary of **120 words or less** (about 60 seconds at 2 words per second) that uses **only facts from the article**.

## How it works
1. **Summarizer.** [`mT5_multilingual_XLSum`](https://huggingface.co/csebuetnlp/mT5_multilingual_XLSum), a Transformer encoder-decoder trained to summarize in 45 languages. We fine-tuned it further on Spanish news from XL-Sum and kept the fine-tuned version only if it improved ROUGE-1 on the validation set. It reads the first 512 tokens of the article and uses beam search to propose 4 candidate summaries.
2. **Fact checker.** Every number and proper name in a candidate must appear in the article. The system keeps the first candidate that passes. If none passes, it shows the one with the fewest unsupported facts and flags it for review before it goes on air.
3. **Interface.** A Gradio web app shows the summary (editable), its word count and estimated airtime, the unsupported facts highlighted in red, how much of the article the model actually read, and the other 3 candidates.

We chose this design because, during evaluation, we found that 4 out of 10 reference summaries written by journalists contain facts that are not in the article body. A model trained to imitate them learns to add outside information, so fine-tuning alone cannot guarantee that the summary only uses facts from the article.

## Results
Same 200 test articles for every system (XL-Sum Spanish test split, seed 42).

<!-- Paste here the table printed by cell 6.5 of the notebook. -->

The notebook also reports 95% bootstrap confidence intervals, 8 charts, an error analysis with 6 cases and the limits of the system.

## Where the model looks: cross-attention
Section 6.2 of the notebook explains the attention mechanism of mT5 and visualizes the **cross-attention** between the summary and the article. In our main example, most of the summary is copied from a single sentence of the article: each summary word attends to the same word in the source. The same map reveals the model's real mistake. It wrote that a food stall is "in Hong Kong" because it attended to the words *Hong Kong* in the stall's name (*Hong Kong Soya Sauce Chicken Rice and Noodle*), but the stall is in Singapore. Errors like this, which use real words from the article in the wrong relation, are the hardest to catch.

## Run it yourself
```bash
pip install -r requirements.txt
python app.py                                   # uses the original mT5 model from Hugging Face
MODEL_DIR=path/to/mt5_radio_cumbres python app.py   # uses our fine-tuned model
```
Open http://localhost:7860. On a CPU each summary takes a few seconds; on a GPU, less than one second.
To run it on Google Colab with a GPU and get a temporary public link, use **Annex A** of the notebook. To publish it on Hugging Face Spaces, use **Annex B**.

## Repository
| Path | What it contains |
| --- | --- |
| `notebooks/entrenamiento.ipynb` | Technical report (Spanish): data, baseline, fine-tuning, evaluation, attention analysis and limits |
| `app.py` | Gradio interface |
| `resumidor.py` | Model loading, candidate generation and the fact checker (the same code the notebook evaluates) |
| `palabras_comunes.txt` | Common Spanish words learned from the training set, so the checker does not confuse capitalized sentence starters with names |
| `space/` | Configuration for Hugging Face Spaces |
| `PROGRESS.md` | Team log for each checkpoint |

## Limitations
- ROUGE compares against a single reference that often contains outside facts, so it cannot measure faithfulness on its own.
- The fact checker only verifies that numbers and names exist in the article, not that they are related correctly.
- The model reads only the first 512 tokens, so information at the end of long articles can be missed.
- It learned the one-sentence style of BBC Mundo leads, so most summaries are much shorter than the 60-second limit.
- It was trained on international news; local news from Radio Cumbres may use names and places it has never seen.

## Data and credits
- Data: [XL-Sum](https://huggingface.co/datasets/csebuetnlp/xlsum), Spanish subset (BBC Mundo), CC BY-NC-SA 4.0.
- Base model: [csebuetnlp/mT5_multilingual_XLSum](https://huggingface.co/csebuetnlp/mT5_multilingual_XLSum), CC BY-NC-SA 4.0.
- For educational use only.
