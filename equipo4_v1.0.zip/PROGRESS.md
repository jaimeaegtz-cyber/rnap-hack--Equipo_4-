# PROGRESS · RNAP Hack 2026 · Reto 2: News in 60 Seconds (Radio Cumbres)
**Equipo 4:** Jaime Esquivel, Alberto Moreno, Jared Dávila, Randhu

<!-- Si este archivo ya tiene las entradas de CP1 y CP2, deja esas arriba y pega las demás debajo. -->

---

## CP3 · Solución con Transformer y evaluación en prueba
**Fecha:** 2026-11-12 · **Archivo:** `notebooks/entrenamiento.ipynb` (secciones 4 y 5)

**Qué hicimos**
- **Ajuste fino** de `csebuetnlp/mT5_multilingual_XLSum` solo con noticias en español de *train* (8,000 artículos, 1 época, Adafactor lr 1e-4, lote efectivo 16, fp32 en GPU T4). Se evalúa la pérdida en *val* cada 100 pasos y se guarda el mejor punto; el paso 0 (sin ajuste) también compite.
- **Verificador de cifras y nombres:** el mT5 genera 4 candidatos con beam search y se elige el primero cuyos números y nombres propios aparezcan en el artículo. Si ninguno pasa, se marca para revisión. Usa una lista de palabras comunes aprendida de *train* para no confundir palabras al inicio de oración con nombres.
- **Decisión con validación:** el modelo ajustado se usa solo si sube ROUGE-1 en *val* (mismo criterio que la longitud del modelo base). *Test* se usó una sola vez, al final.
- **Evaluación en prueba** sobre la misma muestra de la Fase 1 (200 artículos, semilla 42) con ROUGE-1/2/L, % ≤ 120 palabras y tiempo, más una métrica nueva: **% con dato no encontrado** (cifras o nombres que no están en el artículo).
- **Sección 5:** tabla de 5 sistemas (base, mT5 sin ajuste, ajustado, verificador solo, ajustado + verificador), 5 gráficas (curva de aprendizaje, ROUGE, datos sin respaldo, longitud de resúmenes, ROUGE por longitud del artículo) y 6 casos de error elegidos automáticamente por tipo.

**Resultados en prueba**
<!-- Pegar aquí la tabla que imprime la celda 5.5 del cuaderno -->

**Hallazgos**
- En validación, 4 de cada 10 resúmenes del periodista traen datos que no están en el cuerpo de la noticia (p. ej. *Donald* Trump cuando el texto solo dice Trump). El modelo aprende a imitar eso, así que el ajuste fino por sí solo no evita los datos inventados; por eso agregamos el verificador.
- El mT5 solo lee 512 tokens; la sección 5.3 mide en qué fracción de los artículos lo importante queda después del corte.
- El verificador no detecta errores de relación (datos reales mal conectados); la interfaz presenta el resumen como borrador para revisión humana.

**Pendientes**
- Seleccionar oraciones del artículo completo antes del mT5 para no perder el final de las notas largas.
- Revisar con Radio Cumbres si las marcas del verificador son útiles o demasiado estrictas.

---

## CP4 · Interfaz v1 conectada al modelo
**Fecha:** 2026-11-12 · **Archivos:** `app.py`, `resumidor.py`, `palabras_comunes.txt`, `requirements.txt`

**Qué hicimos**
- Interfaz web con **Gradio**. Recibe una noticia nueva (pegada como texto) y muestra:
  - el resumen de 120 palabras o menos, editable, listo para leer al aire;
  - el número de palabras y la duración estimada (2 palabras por segundo);
  - el resultado del verificador: ✅ listo para leer o ⚠️ revisar, con los datos sin respaldo resaltados en rojo;
  - qué parte del artículo alcanzó a leer el modelo (aviso si se cortó en 512 tokens);
  - los 4 candidatos del modelo, con los datos sin respaldo de cada uno.
- `resumidor.py` tiene la misma lógica que el cuaderno (el verificador es el mismo código), para que lo que se evaluó sea lo que corre en la interfaz.
- Incluye una noticia inventada como ejemplo y valida que la entrada tenga al menos 30 palabras.

**Cómo correrla**
```bash
pip install -r requirements.txt
# con el modelo ajustado que guardó el cuaderno (sección 4.5):
MODEL_DIR=/ruta/a/mt5_radio_cumbres python app.py
# sin MODEL_DIR usa el mT5 sin ajuste de Hugging Face
```
En Colab: la celda *Anexo* del cuaderno la abre con `python app.py --share` y da un enlace público temporal.

**Prueba**
- Probada con una nota de *val* donde el mT5 inventa un nombre (*Fernando* González Iñárritu): la interfaz la marca como "Revisar antes de salir al aire" y resalta *Fernando*.
- Probada con la noticia inventada del ejemplo: resumen de 29 palabras (≈14 s) aprobado por el verificador (captura en `capturas/interfaz_v1.png`).
- Estas pruebas se hicieron con el mT5 sin ajuste en CPU: unos 7–12 s por noticia. En la evaluación con GPU T4 el mT5 tardó 0.42 s por artículo.

![Interfaz v1](capturas/interfaz_v1.png)

**Pendientes**
- Publicarla en Hugging Face Spaces (subir el modelo ajustado al Hub y usar su nombre en `MODEL_DIR`).
- Opción para pegar una URL en lugar del texto.

---

## v1.0 · Producto final (PIA)
**Fecha:** 2026-11-19 · **Archivos:** `notebooks/entrenamiento.ipynb` (sección 6), `README.md`, `app.py`, `space/`

**Qué hicimos**
- **Sección 6 del cuaderno:**
  - Tabla final de la línea base contra la solución con Transformer, con intervalos de confianza del 95 % por bootstrap.
  - Explicación del elemento de atención del mT5: consulta, clave y valor; sesgo de posición relativa; y las tres atenciones del codificador-decodificador.
  - Mapa de atención cruzada del ejemplo de la Fase 1 y gráfica de qué parte del artículo usa el modelo.
  - Límites y conclusión final.
- **Corrección a la Fase 1:** el mapa de atención mostró que la frase "todavía no ha decidido dónde colgar" sí está en el artículo. El error real era ubicar el puesto en Hong Kong (parte de su nombre); el puesto está en Singapur. Se agregó una nota en la sección 3.5.
- **Interfaz:**
  - Publicada en Hugging Face Spaces (Anexo B del cuaderno): <!-- pegar enlace -->.
  - Acepta textos desde 10 palabras y avisa cuando el texto es muy corto.
  - Hace un resumen de calentamiento al arrancar para que la primera respuesta no sea lenta.
- **Repositorio:**
  - `README.md` en inglés con el enlace de la interfaz.
  - Cuaderno movido a `notebooks/entrenamiento.ipynb`.

**Resultados finales**
<!-- Pegar aquí la tabla de la celda 6.1 o la de la 6.5 -->

**Decisiones**
- No usamos cuantización int8 para acelerar la interfaz en CPU. Era el doble de rápida, pero cambió 6 de 8 resúmenes de prueba, así que ya no sería el sistema que evaluamos.
- Plan para la demo: abrir la interfaz desde Colab con GPU (menos de 1 s por noticia) y dejar el Space como enlace permanente y como respaldo.

**Trabajo futuro**
- Elegir las oraciones más informativas del artículo completo antes del mT5, para no perder el final de las notas largas.
- Revisar relaciones entre datos (no solo su presencia) y entrenar con resúmenes más largos para aprovechar los 60 segundos.
