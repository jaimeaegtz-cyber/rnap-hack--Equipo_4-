"""
News in 60 Seconds · Radio Cumbres (Equipo 4)
Lógica compartida entre el cuaderno y la interfaz:
  1) el verificador de cifras y nombres (sin dependencias pesadas), y
  2) la clase Resumidor, que carga el mT5 y elige el mejor candidato.
"""
import os
import re
import unicodedata
from collections import Counter

MAX_TOKENS_ENTRADA = 512     # lo que lee el mT5
MAX_TOKENS_SALIDA = 84       # parámetros de la documentación del modelo
NUM_BEAMS = 4
NUM_CANDIDATOS = 4

# --- inicio verificador ---
LIMITE_PALABRAS = 120        # 60 segundos al aire
PALABRAS_POR_SEGUNDO = 2.0   # ritmo de lectura que pide el reto

# Cifras escritas con letra que cuentan como respaldo de una cifra en dígitos
_NUM_PALABRA = {
    '1': ['uno', 'una', 'un', 'primer', 'primera', 'primero'],
    '2': ['dos'], '3': ['tres'], '4': ['cuatro'], '5': ['cinco'], '6': ['seis'],
    '7': ['siete'], '8': ['ocho'], '9': ['nueve'], '10': ['diez'], '11': ['once'],
    '12': ['doce'], '13': ['trece'], '14': ['catorce'], '15': ['quince'],
    '16': ['dieciseis'], '17': ['diecisiete'], '18': ['dieciocho'], '19': ['diecinueve'],
    '20': ['veinte'], '30': ['treinta'], '40': ['cuarenta'], '50': ['cincuenta'],
    '60': ['sesenta'], '70': ['setenta'], '80': ['ochenta'], '90': ['noventa'],
    '100': ['cien', 'ciento'], '1000': ['mil'],
}

# Formas equivalentes comunes en BBC Mundo (el artículo dice "EE.UU." y el resumen "Estados Unidos")
_EEUU = ['ee', 'eeuu', 'eua', 'estadounidense', 'estadounidenses']
_ALIAS = {
    'estados': _EEUU, 'unidos': _EEUU, 'ee': ['estados'], 'uu': ['unidos'], 'eeuu': ['estados'],
    'onu': ['naciones'], 'naciones': ['onu'], 'unidas': ['onu'],
    'us': ['dolar', 'dolares'],                       # "US$2" frente a "2 dólares"
}

# Palabras comunes que llevan mayúscula solo por ir al inicio de una oración
_COMUNES = set('''
el la los las lo un una unos unas al del de en con por para sin sobre entre desde hasta hacia
segun tras ante bajo contra durante mediante y e o u ni pero sino aunque porque pues que quien
quienes cual cuales como cuando donde cuanto cuanta cuantos cuantas este esta estos estas ese esa
esos esas aquel aquella aquellos aquellas esto eso ello el ella ellos ellas yo tu usted ustedes
nosotros nosotras se su sus mi mis nuestro nuestra nuestros nuestras hay es son fue fueron era
eran ha han habia sera seran ser estar esta estan tambien tampoco ya aun todavia mas menos muy
mucho mucha muchos muchas poco pocos pocas todo toda todos todas otro otra otros otras cada
algunos algunas alguno alguna algun ningun ninguna varios varias ambos asi si no solo hoy ayer
manana ahora entonces luego despues antes mientras incluso ademas casi cerca alli aqui ahi nunca
siempre quizas tal tan tanto dicho dicha primer primero primera ultimo ultima nuevo nueva nuevos
nuevas gran grandes mayor mejor peor hace tiene tienen puede pueden cuatro cinco seis siete ocho
nueve diez cientos miles millones
'''.split())


def construir_comunes(textos, min_frec=3):
    """Palabras que en train aparecen más veces en minúscula que con mayúscula inicial
    (p. ej. 'cualquier', 'basta'). Así no se marcan como nombres cuando inician oración."""
    minus, mayus = Counter(), Counter()
    for t in textos:
        for w in re.findall(r'\w+', t):
            (mayus if w[0].isupper() else minus)[sin_acentos(w.lower())] += 1
    return {w for w, n in minus.items() if n >= min_frec and n >= mayus[w] and not w.isdigit()}


def limpiar(texto):
    """Espacios y saltos de línea a un solo espacio (como en la documentación del modelo)."""
    return re.sub(r'\s+', ' ', str(texto).strip())


def sin_acentos(texto):
    return ''.join(c for c in unicodedata.normalize('NFD', texto)
                   if unicodedata.category(c) != 'Mn')


def contar_palabras(texto):
    return len(str(texto).split())


def segundos_al_aire(texto):
    return contar_palabras(texto) / PALABRAS_POR_SEGUNDO


def recortar_palabras(texto, limite=LIMITE_PALABRAS):
    """Garantiza el límite: corta en el último punto antes de pasar de `limite` palabras."""
    palabras = str(texto).split()
    if len(palabras) <= limite:
        return str(texto).strip()
    corto = ' '.join(palabras[:limite])
    fin = max(corto.rfind('.'), corto.rfind('!'), corto.rfind('?'))
    return corto[:fin + 1] if fin > 0 else corto


def _cifras(texto):
    """Cifras en dígitos, sin separadores: '1.500' y '1,500' -> '1500'."""
    return {re.sub(r'[.,]', '', m) for m in re.findall(r'\d+(?:[.,]\d+)*', texto)}


def _nombres(texto):
    """Palabras que empiezan con mayúscula (nombres, siglas, lugares)."""
    return re.findall(r'\b[A-ZÁÉÍÓÚÑÜ][\wáéíóúñüÁÉÍÓÚÑÜ]*', texto)


def datos_no_encontrados(resumen, articulo):
    """Cifras y nombres del resumen que NO aparecen en el artículo.
    Si la lista está vacía, el resumen pasa la verificación."""
    palabras_art = set(re.findall(r'\w+', sin_acentos(articulo.lower())))
    cifras_art = _cifras(articulo)
    faltan = []
    for c in sorted(_cifras(resumen)):
        if c not in cifras_art and not any(p in palabras_art for p in _NUM_PALABRA.get(c, [])):
            faltan.append(c)
    for n in _nombres(resumen):
        clave = sin_acentos(n.lower())
        if clave in palabras_art or clave in _COMUNES or n in faltan:
            continue
        if any(a in palabras_art for a in _ALIAS.get(clave, [])):
            continue
        faltan.append(n)
    return faltan


def elegir_candidato(candidatos, articulo):
    """Recorre los candidatos en el orden del beam search (el primero es el más probable)
    y devuelve el primero que pasa la verificación. Si ninguno pasa, devuelve el que
    tiene menos datos sin respaldo y lo marca para revisión humana."""
    revisados = [(c, datos_no_encontrados(c, articulo)) for c in candidatos]
    for i, (c, faltan) in enumerate(revisados):
        if not faltan:
            return {'resumen': recortar_palabras(c), 'indice': i,
                    'no_encontrados': [], 'aprobado': True}
    i = min(range(len(revisados)), key=lambda k: (len(revisados[k][1]), k))
    return {'resumen': recortar_palabras(revisados[i][0]), 'indice': i,
            'no_encontrados': revisados[i][1], 'aprobado': False}
# --- fin verificador ---

# Lista de palabras comunes construida con train en el cuaderno (sección 4.1)
_RUTA_COMUNES = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'palabras_comunes.txt')
if os.path.exists(_RUTA_COMUNES):
    with open(_RUTA_COMUNES, encoding='utf-8') as f:
        _COMUNES |= set(f.read().split())


class Resumidor:
    """Carga el mT5 (ajustado o sin ajuste) y produce el resumen verificado."""

    def __init__(self, modelo, device=None):
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
        self.torch = torch
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.tok = AutoTokenizer.from_pretrained(modelo)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(modelo).to(self.device).eval()
        self.nombre_modelo = modelo

    def candidatos(self, textos, n=NUM_CANDIDATOS, bs=8):
        """Lista de `n` candidatos por texto, en orden de probabilidad del beam search."""
        salida = []
        for i in range(0, len(textos), bs):
            lote = [limpiar(t) for t in textos[i:i + bs]]
            enc = self.tok(lote, return_tensors='pt', padding=True, truncation=True,
                           max_length=MAX_TOKENS_ENTRADA).to(self.device)
            with self.torch.no_grad():
                ids = self.model.generate(**enc, max_length=MAX_TOKENS_SALIDA, num_beams=NUM_BEAMS,
                                          no_repeat_ngram_size=2, num_return_sequences=n)
            dec = self.tok.batch_decode(ids, skip_special_tokens=True,
                                        clean_up_tokenization_spaces=False)
            salida += [dec[j * n:(j + 1) * n] for j in range(len(lote))]
        return salida

    def cobertura(self, texto):
        """Cuántas palabras del artículo alcanza a leer el modelo (corta en 512 tokens)."""
        ids = self.tok(limpiar(texto), truncation=False).input_ids
        total = contar_palabras(texto)
        if len(ids) <= MAX_TOKENS_ENTRADA:
            return total, total
        leido = self.tok.decode(ids[:MAX_TOKENS_ENTRADA], skip_special_tokens=True)
        return contar_palabras(leido), total

    def resumir(self, texto):
        cands = self.candidatos([texto])[0]
        res = elegir_candidato(cands, limpiar(texto))
        leidas, total = self.cobertura(texto)
        res.update({
            'candidatos': [(c, datos_no_encontrados(c, limpiar(texto))) for c in cands],
            'palabras': contar_palabras(res['resumen']),
            'segundos': segundos_al_aire(res['resumen']),
            'palabras_leidas': leidas,
            'palabras_articulo': total,
        })
        return res
